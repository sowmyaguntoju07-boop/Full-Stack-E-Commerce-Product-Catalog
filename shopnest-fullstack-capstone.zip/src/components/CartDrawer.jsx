import { Minus, Plus, X, ShoppingBag, ArrowRight } from 'lucide-react'

export default function CartDrawer({ open, items, total, onClose, onUpdateQuantity }) {
  if (!open) return null
  return (
    <div className="drawer-backdrop" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <aside className="cart-drawer" aria-label="Shopping bag">
        <div className="drawer-heading"><div><span className="eyebrow">YOUR PICKS</span><h2>Your bag <span>({items.reduce((sum, item) => sum + item.quantity, 0)})</span></h2></div><button className="icon-button" onClick={onClose} aria-label="Close bag"><X /></button></div>
        {items.length === 0 ? <div className="empty-cart"><ShoppingBag size={34} /><h3>Your bag is taking a little nap.</h3><p>Add something lovely and it will show up here.</p><button className="primary-button" onClick={onClose}>Explore the shop</button></div> :
          <>
            <div className="cart-items">{items.map((item) => <div className="cart-item" key={item.id}>
              <img src={item.image} alt="" />
              <div className="cart-item-info"><h3>{item.name}</h3><strong>${(item.price * item.quantity).toFixed(2)}</strong><div className="quantity-control"><button onClick={() => onUpdateQuantity(item.id, item.quantity - 1)} aria-label="Decrease quantity"><Minus size={13} /></button><span>{item.quantity}</span><button onClick={() => onUpdateQuantity(item.id, item.quantity + 1)} aria-label="Increase quantity"><Plus size={13} /></button></div></div>
            </div>)}</div>
            <div className="cart-summary"><div><span>Subtotal</span><strong>${total.toFixed(2)}</strong></div><p>Shipping and taxes calculated at checkout.</p><button className="primary-button checkout-button" onClick={() => window.alert('Demo checkout — connect a backend/payment provider to accept orders.')}>Continue to checkout <ArrowRight size={17} /></button><button className="continue-link" onClick={onClose}>Keep browsing</button></div>
          </>}
      </aside>
    </div>
  )
}