import { Link, NavLink } from 'react-router-dom'
import { ShoppingBag, Menu, X } from 'lucide-react'
import { useState } from 'react'

export default function Header({ cartCount, onCartClick }) {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <header className="site-header">
      <div className="announcement">A little something good for your everyday <span>✳</span> Free shipping over $75</div>
      <div className="nav-wrap container">
        <Link className="brand" to="/" aria-label="ShopNest home"><span className="brand-mark">s.</span><span>shopnest<small>THOUGHTFUL EVERYDAY FINDS</small></span></Link>
        <button className="mobile-menu icon-button" aria-label="Toggle menu" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav-links open' : 'nav-links'}>
          <NavLink to="/" onClick={() => setMenuOpen(false)}>Shop</NavLink>
          <a href="/#featured" onClick={() => setMenuOpen(false)}>Featured</a>
          <NavLink to="/about" onClick={() => setMenuOpen(false)}>Our story</NavLink>
        </nav>
        <button className="cart-button" onClick={onCartClick} aria-label={`Open cart, ${cartCount} items`}><ShoppingBag size={19} /><span>Bag</span><b>{cartCount}</b></button>
      </div>
    </header>
  )
}