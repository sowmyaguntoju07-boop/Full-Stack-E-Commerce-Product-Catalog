import { Star, Plus } from 'lucide-react'

export default function ProductCard({ product, onAdd }) {
  return (
    <article className="product-card">
      <div className={`product-image ${product.color}`}>
        {product.tag && <span className="product-tag">{product.tag}</span>}
        <img src={product.image} alt={product.name} loading="lazy" />
        <button className="quick-add" onClick={() => onAdd(product)} aria-label={`Add ${product.name} to bag`}><Plus size={20} /></button>
      </div>
      <div className="product-meta"><span>{product.category}</span><span className="rating"><Star size={13} fill="currentColor" /> {product.rating}</span></div>
      <div className="product-title-row"><h3>{product.name}</h3><strong>${product.price}</strong></div>
      <p className="product-description">{product.description}</p>
    </article>
  )
}