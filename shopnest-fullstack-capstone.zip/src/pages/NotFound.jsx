import { Link } from 'react-router-dom'
export default function NotFound() {
  return <section className="not-found container"><span className="eyebrow">WELL, THIS IS AWKWARD</span><h1>Looks like this page<br /><em wandered off.</em></h1><p>The page you are looking for isn't here, but there's plenty to discover back at the shop.</p><Link className="primary-button" to="/">Back to ShopNest</Link></section>
}