import { useMemo, useState } from 'react'
import { Search, SlidersHorizontal, ArrowDownRight, Sparkles } from 'lucide-react'
import ProductCard from '../components/ProductCard.jsx'
import { categories } from '../data/products.js'

export default function Home({ products, onAddToCart }) {
  const [category, setCategory] = useState('All')
  const [search, setSearch] = useState('')
  const [sort, setSort] = useState('featured')

  const visibleProducts = useMemo(() => {
    let result = products.filter((p) => (category === 'All' || p.category === category) && `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(search.toLowerCase()))
    if (sort === 'price-low') result = [...result].sort((a, b) => a.price - b.price)
    if (sort === 'price-high') result = [...result].sort((a, b) => b.price - a.price)
    if (sort === 'rating') result = [...result].sort((a, b) => b.rating - a.rating)
    return result
  }, [products, category, search, sort])

  return <>
    <section className="hero container">
      <div className="hero-copy"><span className="eyebrow"><Sparkles size={14} /> GOOD THINGS, GATHERED</span><h1>Make room for<br /><em>little joys.</em></h1><p>Everyday essentials with a little extra thought. Useful, beautiful things that make your space feel more like you.</p><a className="hero-cta" href="#featured">Find your favorites <ArrowDownRight size={18} /></a><div className="hero-note"><span className="note-dot"></span> Curated with care, made to be lived with.</div></div>
      <div className="hero-art"><div className="hero-image-main"><img src="https://images.unsplash.com/photo-1490312278390-ab64016e0aa9?auto=format&fit=crop&w=1200&q=85" alt="Warm, sunlit home interior with thoughtful everyday objects" fetchPriority="high" /></div><div className="floating-note"><span>THE SLOW LIVING EDIT</span><strong>Good design.<br />Easy living.</strong><span className="scribble">✳</span></div><div className="hero-stamp">PICKED<br />WITH ♥</div></div>
    </section>
    <section className="value-strip"><div className="container value-items"><span>✳ Thoughtfully curated</span><span>↗ Everyday quality</span><span>♡ Less, but better</span><span>☼ Made for real life</span></div></section>
    <section id="featured" className="catalog-section container">
      <div className="section-heading"><div><span className="eyebrow">THE GOOD STUFF</span><h2>Find your <em>everyday.</em></h2><p>Useful little things, picked to make life feel good.</p></div><span className="product-count">{visibleProducts.length} lovely finds</span></div>
      <div className="catalog-toolbar"><div className="category-tabs" aria-label="Filter products by category">{categories.map((item) => <button key={item} className={category === item ? 'category-tab active' : 'category-tab'} onClick={() => setCategory(item)}>{item}</button>)}</div><div className="catalog-controls"><label className="search-box"><Search size={16} /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Find something..." aria-label="Search products" /></label><label className="sort-box"><SlidersHorizontal size={15} /><select value={sort} onChange={(e) => setSort(e.target.value)} aria-label="Sort products"><option value="featured">Featured</option><option value="price-low">Price: low to high</option><option value="price-high">Price: high to low</option><option value="rating">Top rated</option></select></label></div></div>
      {visibleProducts.length ? <div className="product-grid">{visibleProducts.map((product) => <ProductCard key={product.id} product={product} onAdd={onAddToCart} />)}</div> : <div className="no-results"><span>☁</span><h3>No little joys found just yet.</h3><p>Try another search or category.</p><button className="secondary-button" onClick={() => { setSearch(''); setCategory('All') }}>Clear filters</button></div>}
    </section>
    <section className="newsletter-section"><div className="newsletter-inner container"><div><span className="eyebrow">A NOTE FROM US</span><h2>Good things, straight<br /><em>to your inbox.</em></h2><p>Fresh finds, small rituals, and the occasional lovely surprise.</p></div><form className="newsletter-form" onSubmit={(e) => { e.preventDefault(); window.alert('Thanks for joining the demo newsletter!') }}><label htmlFor="email">Your email address</label><div><input id="email" type="email" required placeholder="you@example.com" /><button type="submit">Count me in <ArrowDownRight size={17} /></button></div><small>No noise. Just the good stuff.</small></form></div></section>
  </>
}