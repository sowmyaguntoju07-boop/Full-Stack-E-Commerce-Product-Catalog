# ShopNest — Full-Stack Deployment & Project Architecture

A responsive e-commerce product catalog built with React, Vite, and React Router. This capstone demonstrates modular components, client-side routing, category filtering, search, sorting, a working cart drawer, responsive design, and production deployment configuration.

## Requirements

- Node.js 18+ (recommended)
- npm

## Run locally

```bash
npm install
npm run dev
```

Open the local URL shown in the terminal.

## Production build

```bash
npm run build
npm run preview
```

Vite creates the optimized production build in `dist/`.

## Deploy (Vercel)

1. Push this folder to a GitHub repository.
2. Sign in to Vercel and import the repository.
3. Framework preset: **Vite**.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Deploy and copy the public URL for your assignment submission.

The included `vercel.json` supports client-side routes.

## Deploy (Netlify)

1. Push the project to GitHub and import it in Netlify, or upload the project through Netlify's supported Git workflow.
2. Build command: `npm run build`.
3. Publish directory: `dist`.
4. Deploy. The included `netlify.toml` handles SPA route fallback.

## Project structure

```text
src/
  components/
    CartDrawer.jsx
    Footer.jsx
    Header.jsx
    ProductCard.jsx
  data/
    products.js
  pages/
    About.jsx
    Home.jsx
    NotFound.jsx
  App.jsx
  main.jsx
  styles.css
```

## Features checklist

- [x] Modular component-based frontend
- [x] Client-side routing (`/`, `/about`)
- [x] Product search and category filters
- [x] Sort by price and rating
- [x] Add/remove items and adjust cart quantities
- [x] Responsive layout for mobile and desktop
- [x] Image lazy-loading
- [x] Production build configuration
- [x] Vercel and Netlify SPA routing configuration

## Notes

- Product images are loaded from Unsplash and need an internet connection.
- Cart contents are kept in React state and reset on refresh; no backend or payment processing is included. This is a frontend capstone demo, not a live commerce system.
- Before submitting, run `npm install` and `npm run build`, deploy it, and submit the live URL requested by your course.
